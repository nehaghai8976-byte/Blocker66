package com.cleanmind.app

import android.content.Context
import android.os.SystemClock
import android.provider.Settings

/** 10 min reels dekho, phir 5 min break. Har app ka alag counter. */
object ReelBreak {
    const val WATCH_MS = 10 * 60 * 1000L
    const val BREAK_MS = 5 * 60 * 1000L

    private fun p(c: Context) = c.getSharedPreferences("reelbreak", Context.MODE_PRIVATE)
    private fun boot(c: Context) = Settings.Global.getInt(c.contentResolver, Settings.Global.BOOT_COUNT, -1)

    fun breakLeft(c: Context, key: String): Long {
        val s = p(c)
        var left = s.getLong("wall_$key", 0) - System.currentTimeMillis()
        if (s.getInt("boot_$key", -2) == boot(c)) {
            left = maxOf(left, s.getLong("el_$key", 0) - SystemClock.elapsedRealtime())
        }
        return maxOf(left, 0)
    }

    /** Dekhne ka time jodta hai. 10 min poore hone par break shuru karke true return karta hai. */
    fun addWatch(c: Context, key: String, ms: Long): Boolean {
        val s = p(c)
        val used = s.getLong("used_$key", 0) + ms
        if (used >= WATCH_MS) {
            s.edit()
                .putLong("used_$key", 0)
                .putLong("wall_$key", System.currentTimeMillis() + BREAK_MS)
                .putLong("el_$key", SystemClock.elapsedRealtime() + BREAK_MS)
                .putInt("boot_$key", boot(c))
                .apply()
            return true
        }
        s.edit().putLong("used_$key", used).apply()
        return false
    }
}
