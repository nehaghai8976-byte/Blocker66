package com.cleanmind.app

import android.accessibilityservice.AccessibilityService
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.net.Uri
import android.net.VpnService
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.TextView
import android.widget.Toast

class BlockerService : AccessibilityService() {

    companion object {
        const val OFF = 0
        const val REELS = 1
        const val FULL = 2
        const val BREAK = 3
    }

    // ---- Lock ke time band hone wale system screens ----
    private val settingsPkgs = setOf("com.android.settings", "com.miui.securitycenter",
        "com.coloros.safecenter", "com.oplus.safecenter", "com.samsung.android.lool")
    // Phone Manager / Security / Device Care apps (app ko kill ya freeze kar sakte hain)
    private val managerPkgs = setOf(
        "com.coloros.phonemanager", "com.oplus.phonemanager", "com.coloros.oppoguardelf",
        "com.coloros.safecenter", "com.oplus.safecenter", "com.oppo.safe", "com.oplus.battery",
        "com.miui.securitycenter", "com.iqoo.secure", "com.vivo.abe", "com.huawei.systemmanager",
        "com.samsung.android.lool", "com.samsung.android.sm"
    )
    private val installerPkgs = setOf("com.google.android.packageinstaller", "com.android.packageinstaller",
        "com.samsung.android.packageinstaller", "com.miui.packageinstaller")
    private val blockedTitles = listOf(
        "accessibility", "additional settings", "device admin", "device administrator",
        "vpn", "private dns", "date & time", "date and time", "install unknown apps",
        "special app access", "installed services", "downloaded apps",
        "battery optimization", "optimize battery usage", "auto launch", "auto-launch", "autostart", "startup manager",
        "एक्सेसिबिलिटी", "अतिरिक्त सेटिंग", "डिवाइस एडमिन"
    )

    // ---- Porn keyword scan: Chrome + Telegram + Google app ----
    private val watched = setOf(
        "com.android.chrome", "org.telegram.messenger", "org.telegram.messenger.web",
        "org.thunderdog.challegram", "com.google.android.googlequicksearchbox"
    )
    private val keywords = listOf(
        "porn", "xxx", "xvideos", "xnxx", "xhamster", "redtube", "youporn", "brazzers",
        "onlyfans", "hentai", "spankbang", "eporner", "erome", "fapello", "chudai",
        "desi sex", "sex video", "blue film", "camgirl", "adult video", "nude video"
    )

    // ---- Play Store: 13+ rating wale app ka page khulte hi band ----
    private val badRating = Regex("rated for (1[3-9]|[2-9][0-9])\\+|rated for (teen|mature|adults)")

    // ---- Social apps ----
    private val igPkgs = setOf("com.instagram.android", "com.instagram.lite")
    private val fbPkgs = setOf("com.facebook.katana", "com.facebook.lite")
    private val ytPkgs = setOf("com.google.android.youtube")

    // ---- Browsers (Chrome ke alawa sab block) ----
    private var browsers: Set<String> = emptySet()
    private var lastBrowserLoad = 0L

    private var lastScan = 0L
    private var lastVpnCheck = 0L
    private var lastPlay = 0L
    private var lastSocial = 0L
    private var lastSignup = 0L
    private var lastWeb = 0L
    private var lastVpnGuard = 0L
    private var lastWebApp = 0L

    // ---- Play Store "Install" button ke upar cover (tap hi nahi hoga) ----
    private val overlays = mutableListOf<View>()
    private var lastRects: List<Rect> = emptyList()
    private val installLabels = setOf("install", "इंस्टॉल करें", "इंस्टॉल")
    private val safeRating = Regex("rated for (3|7|12)\\+")

    private fun removeOverlays() {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        overlays.forEach { try { wm.removeView(it) } catch (_: Exception) {} }
        overlays.clear()
        lastRects = emptyList()
    }

    private fun addCover(r: Rect) {
        if (r.width() <= 0 || r.height() <= 0) return
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val v = TextView(this).apply {
            text = "Blocked"
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            textSize = 12f
            setBackgroundColor(0xEE444444.toInt())
            setOnTouchListener { _, e ->
                if (e.action == MotionEvent.ACTION_UP) {
                    Toast.makeText(this@BlockerService, "13+ ya unknown rating. Download blocked", Toast.LENGTH_SHORT).show()
                }
                true
            }
        }
        val lp = WindowManager.LayoutParams(
            r.width(), r.height(), WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = r.left; y = r.top }
        try { wm.addView(v, lp); overlays.add(v) } catch (_: Exception) {}
    }

    // Page ki rating 3+/7+/12+ saaf dikhe tabhi Install khulega, warna button ke upar cover
    private fun updateInstallCover(root: AccessibilityNodeInfo, txt: String) {
        val safe = safeRating.containsMatchIn(txt) && !badRating.containsMatchIn(txt) &&
                !appRegex.containsMatchIn(txt.take(300))
        if (safe) { if (overlays.isNotEmpty()) removeOverlays(); return }
        val rects = mutableListOf<Rect>()
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        var n = 0
        while (queue.isNotEmpty() && n < 600) {
            val node = queue.removeFirst()
            n++
            val t = node.text?.toString()?.trim()?.lowercase()
            if (t != null && t in installLabels && node.isVisibleToUser) {
                val r = Rect()
                node.getBoundsInScreen(r)
                rects.add(r)
            }
            for (i in 0 until node.childCount) node.getChild(i)?.let { queue.add(it) }
        }
        if (rects == lastRects) return
        removeOverlays()
        rects.forEach { addCover(it) }
        lastRects = rects
    }
    private var blockedPkgs: Set<String> = emptySet()

    // Block hui apps ki list (khulte hi HOME)
    private fun loadBlocked() {
        blockedPkgs = (getSharedPreferences("lock", MODE_PRIVATE)
            .getStringSet("blocked_pkgs", emptySet()) ?: emptySet()).toSet()
    }

    private fun addBlocked(p: String) {
        val sp = getSharedPreferences("lock", MODE_PRIVATE)
        val set = (sp.getStringSet("blocked_pkgs", emptySet()) ?: emptySet()).toMutableSet()
        set.add(p)
        sp.edit().putStringSet("blocked_pkgs", set).apply()
        blockedPkgs = set
    }

    // Phone me pehle se installed apps me bhi bad naam wale dhundho
    private fun scanInstalled() {
        try {
            packageManager.getInstalledApplications(0).forEach { ai ->
                if ((ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0 || ai.packageName == packageName) return@forEach
                val label = packageManager.getApplicationLabel(ai).toString().lowercase()
                if (appRegex.containsMatchIn(label) || pkgHints.any { ai.packageName.lowercase().contains(it) }) {
                    addBlocked(ai.packageName)
                }
            }
        } catch (_: Exception) {}
    }

    // App/page ke naam me ye words aaye to block (word-boundary match)
    private val appKeywords = listOf(
        "video downloader", "video call", "video calls", "video chat", "live video chat", "random chat",
        "talk to strangers", "dating", "omegle", "chatroulette", "bigo", "azar", "uplive",
        "live girls", "girl chat", "anonymous chat", "hookup", "flirt", "vidmate", "snaptube",
        "tubemate", "reels downloader", "story saver", "status saver", "live talk"
    )
    private val appRegex = Regex("\\b(" + appKeywords.joinToString("|") { Regex.escape(it) } + ")\\b")
    private val pkgHints = listOf("videodownloader", "videocall", "videochat", "randomchat", "vidmate", "snaptube")

    // Jin pages pe bad rating/keyword mila unka text yaad rakho (install ke baad naam match karne ke liye)
    private val flagged = ArrayDeque<Pair<Long, String>>()
    private var pendingLabel: String? = null
    private var receiverOn = false

    private val installReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            if (i.getBooleanExtra(Intent.EXTRA_REPLACING, false)) return
            val p = i.data?.schemeSpecificPart ?: return
            if (p == packageName) return
            val label = try {
                packageManager.getApplicationLabel(packageManager.getApplicationInfo(p, 0)).toString().lowercase()
            } catch (_: Exception) { return }
            val now = System.currentTimeMillis()
            val bad = appRegex.containsMatchIn(label) || pkgHints.any { p.lowercase().contains(it) } ||
                    (label.length >= 4 && flagged.any { now - it.first < 600_000 && it.second.contains(label) })
            if (bad) { addBlocked(p); startUninstall(p, label) }
        }
    }

    // Naya account banane ke screens/buttons (exact text match, taaki captions se confuse na ho)
    private val signupScreens = setOf("create account", "create an account", "sign up",
        "sign up with email or phone number", "साइन अप", "खाता बनाएं")
    private val createClicks = listOf("create new account", "नया खाता बनाएं", "create account", "sign up")

    private val handler = Handler(Looper.getMainLooper())
    private var lastTick = 0L
    private val tick = object : Runnable {
        override fun run() {
            try { loadBlocked(); reelTick() } catch (_: Exception) {}
            if (Lock.isLocked(this@BlockerService)) ensureVpn()
            handler.postDelayed(this, 2000)
        }
    }

    override fun onServiceConnected() {
        loadBrowsers(); ensureVpn(); loadBlocked(); scanInstalled()
        if (!receiverOn) {
            val f = IntentFilter(Intent.ACTION_PACKAGE_ADDED)
            f.addDataScheme("package")
            try {
                if (Build.VERSION.SDK_INT >= 33) registerReceiver(installReceiver, f, Context.RECEIVER_EXPORTED)
                else registerReceiver(installReceiver, f)
                receiverOn = true
            } catch (_: Exception) {}
        }
        handler.removeCallbacks(tick)
        handler.post(tick)
    }

    override fun onUnbind(intent: Intent?): Boolean {
        handler.removeCallbacks(tick)
        removeOverlays()
        if (receiverOn) { try { unregisterReceiver(installReceiver) } catch (_: Exception) {}; receiverOn = false }
        return super.onUnbind(intent)
    }

    // Har 2 sec: agar reel khuli hai to dekhne ka time gino, 10 min par 5 min break
    private fun reelTick() {
        val now = SystemClock.elapsedRealtime()
        val delta = minOf(now - lastTick, 3000L).coerceAtLeast(0L)
        lastTick = now
        val root = rootInActiveWindow ?: return
        val pkg = root.packageName?.toString() ?: return
        if (pkg != "com.android.vending" && overlays.isNotEmpty()) removeOverlays()
        if (pkg in blockedPkgs) { kick("Ye app blocked hai"); return }
        if (pkg == "com.android.vending") { guardPlayStore(); return }
        if (pkg in installerPkgs) { if (!confirmUninstall()) guardInstaller(); return }
        val key = when {
            pkg in igPkgs -> "ig"
            pkg in fbPkgs -> "fb"
            pkg in ytPkgs -> "yt"
            else -> return
        }
        if (getSharedPreferences("lock", MODE_PRIVATE).getInt("app_$key", OFF) != BREAK) return
        if (!inReels(key, root)) return
        if (ReelBreak.breakLeft(this, key) > 0) { blockDuringBreak(key); return }
        if (ReelBreak.addWatch(this, key, delta)) blockDuringBreak(key)
    }

    private fun blockDuringBreak(key: String) {
        performGlobalAction(GLOBAL_ACTION_BACK)
        val mins = ReelBreak.breakLeft(this, key) / 60000 + 1
        Toast.makeText(this, "Reel break chal raha hai: $mins min baaki", Toast.LENGTH_SHORT).show()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName) return

        if (pkg != "com.android.vending" && overlays.isNotEmpty()) removeOverlays()
        if (pkg in blockedPkgs) { kick("Ye app blocked hai"); return }

        if (System.currentTimeMillis() - lastBrowserLoad > 600_000) { loadBrowsers(); scanInstalled() }

        // Instagram/Facebook me "Create new account" dabate hi band
        if (event.eventType == AccessibilityEvent.TYPE_VIEW_CLICKED && (pkg in igPkgs || pkg in fbPkgs)) {
            val t = (event.text.joinToString(" ") + " " + (event.contentDescription ?: "")).lowercase()
            if (createClicks.any { t.contains(it) }) { kick("Naya account banana blocked"); return }
        }

        // Play Store me kuch bhi dabate hi turant check (slow phone me bhi)
        if (event.eventType == AccessibilityEvent.TYPE_VIEW_CLICKED && pkg == "com.android.vending") {
            guardPlayStore(force = true)
        }
        // Installer dialog: uninstall auto-confirm ya bad app install roko
        if (pkg in installerPkgs) {
            if (confirmUninstall()) return
            guardInstaller()
        }

        if (Lock.isLocked(this)) {
            ensureVpn()
            if (pkg in managerPkgs) { kick("Lock ke time Phone Manager band"); return }
            if (pkg in settingsPkgs && guardVpnScreen()) return
            if (guardSystemScreens(pkg, event)) return
        }
        when {
            pkg in browsers -> kick("Sirf Chrome allowed hai")
            pkg == "com.android.vending" -> guardPlayStore()
            pkg in igPkgs || pkg in fbPkgs || pkg in ytPkgs -> guardSocial(pkg)
            pkg in watched -> { scanForPorn(); if (pkg == "com.android.chrome") { guardWebSignup(); guardWebApps() } }
        }
    }

    // ================= Browsers =================
    private fun loadBrowsers() {
        lastBrowserLoad = System.currentTimeMillis()
        val set = mutableSetOf<String>()
        try {
            val i = Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_BROWSER)
            packageManager.queryIntentActivities(i, PackageManager.MATCH_ALL)
                .forEach { set.add(it.activityInfo.packageName) }
        } catch (_: Exception) {}
        set += listOf("org.mozilla.firefox", "org.mozilla.fenix", "com.sec.android.app.sbrowser",
            "com.microsoft.emmx", "com.brave.browser", "com.opera.browser", "com.opera.mini.native",
            "com.UCMobile.intl", "com.duckduckgo.mobile.android", "com.android.browser",
            "com.mi.globalbrowser", "com.heytap.browser", "com.kiwibrowser.browser", "com.vivaldi.browser")
        set.remove("com.android.chrome")
        set.remove(packageName)
        browsers = set
    }

    // ================= Play Store / Installer =================
    private fun guardPlayStore(force: Boolean = false) {
        val now = System.currentTimeMillis()
        if (!force && now - lastPlay < 300) return
        lastPlay = now
        val txt = rootText()
        if (badRating.containsMatchIn(txt) || appRegex.containsMatchIn(txt.take(300))) {
            flagged.addLast(Pair(now, txt.take(400)))
            while (flagged.size > 6) flagged.removeFirst()
            removeOverlays()
            kick("Ye app install nahi hoga")
            return
        }
        rootInActiveWindow?.let { updateInstallCover(it, txt) }
    }

    private fun guardInstaller() {
        if (pendingLabel != null) return
        val txt = rootText()
        if (txt.contains("uninstall")) return
        if (appRegex.containsMatchIn(txt)) kick("Ye app install nahi hoga")
    }

    // Bad app install ho gaya to uninstall dialog kholo aur khud OK dabao
    private fun startUninstall(pkg: String, label: String) {
        pendingLabel = label
        try {
            startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            Toast.makeText(this, "Blocked app hata raha hoon", Toast.LENGTH_SHORT).show()
        } catch (_: Exception) { pendingLabel = null }
    }

    private fun confirmUninstall(): Boolean {
        val label = pendingLabel ?: return false
        val root = rootInActiveWindow ?: return false
        if (!rootText().contains(label)) return false
        val targets = setOf("ok", "uninstall", "delete", "ठीक है")
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        var n = 0
        while (queue.isNotEmpty() && n < 400) {
            val node = queue.removeFirst()
            n++
            val t = node.text?.toString()?.trim()?.lowercase()
            if (t != null && t in targets) {
                var c: AccessibilityNodeInfo? = node
                while (c != null && !c.isClickable) c = c.parent
                if (c != null) { c.performAction(AccessibilityNodeInfo.ACTION_CLICK); pendingLabel = null; return true }
            }
            for (i in 0 until node.childCount) node.getChild(i)?.let { queue.add(it) }
        }
        return false
    }

    // ================= Instagram / Facebook / YouTube =================
    private fun guardSocial(pkg: String) {
        val key = when {
            pkg in igPkgs -> "ig"
            pkg in fbPkgs -> "fb"
            else -> "yt"
        }
        if (key != "yt") {
            val t = System.currentTimeMillis()
            if (t - lastSignup > 500) {
                lastSignup = t
                val r = rootInActiveWindow
                if (r != null && hasSignupText(r)) { kick("Naya account banana blocked"); return }
            }
        }
        val mode = getSharedPreferences("lock", MODE_PRIVATE).getInt("app_$key", OFF)
        if (mode == FULL) { kick("Ye app blocked hai"); return }
        if (mode == BREAK) {
            if (ReelBreak.breakLeft(this, key) > 0) {
                val r = rootInActiveWindow ?: return
                if (inReels(key, r)) blockDuringBreak(key)
            }
            return
        }
        if (mode != REELS) return

        val now = System.currentTimeMillis()
        if (now - lastSocial < 400) return
        lastSocial = now
        val root = rootInActiveWindow ?: return
        if (inReels(key, root)) {
            performGlobalAction(GLOBAL_ACTION_BACK)
            Toast.makeText(this, "Reels/Shorts blocked", Toast.LENGTH_SHORT).show()
        }
    }

    private fun hasSignupText(root: AccessibilityNodeInfo): Boolean {
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        var n = 0
        while (queue.isNotEmpty() && n < 600) {
            val node = queue.removeFirst()
            n++
            val t = node.text?.toString()?.trim()?.lowercase()
            val d = node.contentDescription?.toString()?.trim()?.lowercase()
            if ((t != null && t in signupScreens) || (d != null && d in signupScreens)) return true
            for (i in 0 until node.childCount) node.getChild(i)?.let { queue.add(it) }
        }
        return false
    }

    // Chrome: video downloader / video call jaise keywords (URL ya search me)
    private fun guardWebApps() {
        val now = System.currentTimeMillis()
        if (now - lastWebApp < 600) return
        lastWebApp = now
        if (appRegex.containsMatchIn(rootText().take(400))) kick("Blocked")
    }

    // Chrome me instagram.com / facebook.com ka sign up page
    private fun guardWebSignup() {
        val now = System.currentTimeMillis()
        if (now - lastWeb < 600) return
        lastWeb = now
        val root = rootInActiveWindow ?: return
        val txt = rootText()
        if ((txt.contains("instagram.com") || txt.contains("facebook.com")) && hasSignupText(root)) {
            kick("Naya account banana blocked")
        }
    }

    private fun inReels(key: String, root: AccessibilityNodeInfo): Boolean {
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        var n = 0
        while (queue.isNotEmpty() && n < 600) {
            val node = queue.removeFirst()
            n++
            val id = node.viewIdResourceName?.lowercase() ?: ""
            val desc = node.contentDescription?.toString()?.lowercase() ?: ""
            val hit = when (key) {
                "ig" -> id.contains("clips_viewer") || id.contains("reel_viewer") ||
                        (id.endsWith("clips_tab") && node.isSelected)
                "yt" -> id.contains("reel_recycler") || id.contains("reel_player_page_container") ||
                        id.contains("shorts_player")
                else -> id.contains("reels_viewer") || id.contains("reel_viewer") ||
                        (desc.startsWith("reels") && node.isSelected)
            }
            if (hit) return true
            for (i in 0 until node.childCount) node.getChild(i)?.let { queue.add(it) }
        }
        return false
    }

    // VPN settings screen (Clean Mind ka VPN entry / disconnect / forget) band
    private fun guardVpnScreen(): Boolean {
        val now = System.currentTimeMillis()
        if (now - lastVpnGuard < 400) return false
        lastVpnGuard = now
        val label = applicationInfo.loadLabel(packageManager).toString().lowercase()
        val t = rootText()
        if (t.contains(label) && (t.contains("vpn") || t.contains("always-on") ||
                    t.contains("forget") || t.contains("disconnect"))) {
            return kick("VPN band nahi hoga")
        }
        return false
    }

    // ================= Lock: system screens =================
    private fun guardSystemScreens(pkg: String, event: AccessibilityEvent): Boolean {
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return false
        val title = event.text.joinToString(" ").lowercase()
        val cls = event.className?.toString()?.lowercase() ?: ""
        val label = applicationInfo.loadLabel(packageManager).toString().lowercase()

        when {
            pkg == "com.android.vpndialogs" -> return kick("VPN band nahi hoga")
            pkg == "com.android.vending" ->
                if (title.contains("parental controls")) return kick("Lock ke time locked")
            pkg in settingsPkgs || pkg in installerPkgs -> {
                if (blockedTitles.any { title.contains(it) }) return kick("Lock chalu hai")
                val appInfo = title.contains("app info") || cls.contains("appdetails") ||
                        cls.contains("appinfo") || pkg in installerPkgs
                if (appInfo && rootText().contains(label)) return kick("Lock chalu hai")
            }
        }
        return false
    }

    // ================= Porn keyword scan =================
    private fun scanForPorn() {
        val now = System.currentTimeMillis()
        if (now - lastScan < 400) return
        lastScan = now
        val text = rootText()
        if (keywords.any { text.contains(it) }) kick("Blocked. Tu strong hai bhai 💪")
    }

    private fun rootText(): String {
        val root = rootInActiveWindow ?: return ""
        val sb = StringBuilder()
        var count = 0
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null || count > 400) return
            count++
            n.text?.let { sb.append(it).append(' ') }
            n.contentDescription?.let { sb.append(it).append(' ') }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        return sb.toString().lowercase()
    }

    private fun kick(msg: String): Boolean {
        performGlobalAction(GLOBAL_ACTION_HOME)
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
        return true
    }

    private fun ensureVpn() {
        val now = System.currentTimeMillis()
        if (now - lastVpnCheck < 5000) return
        lastVpnCheck = now
        val wanted = getSharedPreferences("lock", MODE_PRIVATE).getBoolean("vpn_on", false)
        if (wanted && !DnsVpnService.active && VpnService.prepare(this) == null) {
            try { startService(Intent(this, DnsVpnService::class.java)) } catch (_: Exception) {}
        }
    }

    override fun onInterrupt() {}
}
